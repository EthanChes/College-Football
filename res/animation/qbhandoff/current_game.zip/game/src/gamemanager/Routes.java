package gamemanager;

public class Routes {
}
